import React, { useState } from "react";
import { View, Text, Switch } from "react-native";

export default function SettingsScreen() {
  const [darkMode, setDarkMode] = useState(false);
  const [notification, setNotification] = useState(true);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <View style={{ flexDirection: "row", justifyContent: "space-between", marginBottom: 20 }}>
        <Text style={{ fontSize: 18 }}>🌙 Dark Mode</Text>
        <Switch value={darkMode} onValueChange={setDarkMode} />
      </View>
      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Text style={{ fontSize: 18 }}>🔔 Nhận thông báo</Text>
        <Switch value={notification} onValueChange={setNotification} />
      </View>
    </View>
  );
}
