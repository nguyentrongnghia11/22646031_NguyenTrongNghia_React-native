import React from "react";
import { View, Text, Image } from "react-native";

export default function ProfileScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>Nguyen trong ngghia</Text>
      <Text style={{ fontSize: 16, color: "#666" }}>Email: nghianguyen15012004@gmail.com</Text>
    </View>
  );
}
