import React, { useEffect, useState } from "react";
import { View, Text, FlatList, TouchableOpacity, Image, ActivityIndicator } from "react-native";

export default function ProductsScreen({ navigation }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("https://67cd35e2dd7651e464eda65e.mockapi.io/phones")
      .then((res) => res.json())
      .then((json) => {
        setData(json);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Fetch error:", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="tomato" />
        <Text>Đang tải dữ liệu...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 16, backgroundColor: "#f2f2f2" }}>
      <FlatList
        data={data}
        keyExtractor={(item) => item.id.toString()}
        numColumns={2}
        columnWrapperStyle={{ justifyContent: "space-between" }}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => navigation.navigate("ProductDetails", { product: item })}
            style={{
              backgroundColor: "white",
              padding: 10,
              marginBottom: 15,
              borderRadius: 12,
              flex: 1,
              marginHorizontal: 5,
              shadowColor: "#000",
              shadowOpacity: 0.1,
              shadowOffset: { width: 0, height: 2 },
              shadowRadius: 4,
              elevation: 3,
              alignItems: "center",
            }}
          >
            <Image
              source={{ uri: item.imgURL }}
              style={{ width: 120, height: 120, resizeMode: "contain", marginBottom: 10 }}
            />
            <Text style={{ fontSize: 16, fontWeight: "600", color: "#333" }}>{item.name}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
