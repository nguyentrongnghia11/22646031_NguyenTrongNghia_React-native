import React from "react";
import { View, Text, TouchableOpacity, Image } from "react-native";
import { useFavorites } from "../context/FavoritesContext";

export default function  ProductDetailsScreen({ route }) {
  const { product } = route.params;
  const { addToFavorites } = useFavorites();

  return (
    <View style={{ flex: 1, padding: 20, alignItems: "center", backgroundColor: "#fff" }}>
      <Image
        source={{ uri: product.imgURL }}
        style={{ width: 200, height: 200, resizeMode: "contain", marginBottom: 20 }}
      />
      <Text style={{ fontSize: 22, fontWeight: "bold", marginBottom: 10 }}>{product.name}</Text>
      <Text style={{ fontSize: 16, color: "#666", marginBottom: 20 }}>ID: {product.id}</Text>

      <TouchableOpacity
        onPress={() => addToFavorites(product)}
        style={{
          backgroundColor: "tomato",
          paddingVertical: 12,
          paddingHorizontal: 30,
          borderRadius: 8,
        }}
      >
        <Text style={{ color: "white", fontWeight: "bold", fontSize: 16 }}>LƯU VÀO FAVORITES</Text>
      </TouchableOpacity>
    </View>
  );
}
