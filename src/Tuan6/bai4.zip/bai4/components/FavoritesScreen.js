import React from "react";
import { View, Text, FlatList, Image } from "react-native";
import { useFavorites } from "../context/FavoritesContext";

export default function FavoritesScreen() {
  const { favorites } = useFavorites();

  if (favorites.length === 0) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text style={{ fontSize: 16 }}>Chưa có sản phẩm nào được lưu</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, padding: 16, backgroundColor: "#f9f9f9" }}>
      <FlatList
        data={favorites}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View
            style={{
              backgroundColor: "white",
              padding: 12,
              marginBottom: 12,
              borderRadius: 10,
              flexDirection: "row",
              alignItems: "center",
              shadowColor: "#000",
              shadowOpacity: 0.1,
              shadowOffset: { width: 0, height: 2 },
              shadowRadius: 4,
              elevation: 2,
            }}
          >
            <Image
              source={{ uri: item.imgURL }}
              style={{ width: 60, height: 60, resizeMode: "contain", marginRight: 12 }}
            />
            <Text style={{ fontSize: 18, fontWeight: "500" }}>{item.name}</Text>
          </View>
        )}
      />
    </View>
  );
}
