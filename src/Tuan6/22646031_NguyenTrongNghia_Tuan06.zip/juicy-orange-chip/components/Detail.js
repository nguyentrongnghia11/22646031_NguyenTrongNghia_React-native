import { Text, View, Image, TouchableOpacity } from 'react-native';

export default function Detail({ navigation }) {
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={{ padding: 20, alignItems: 'center', flexDirection: 'row' }}>
        <Image
          source={require('../assets/vs_blue.png')}
          style={{ width: 150, height: 200, resizeMode: 'contain' }}
        />
        <Text style={{ marginTop: 10, fontSize: 16, fontWeight: 'bold' }}>
          Điện Thoại Vsmart Joy 3 Hàng chính hãng
        </Text>
      </View>

      <View
        style={{
          flex: 2,
          backgroundColor: '#D9D9D9',
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,

          alignItems: 'center',
        }}>
        <Text style={{ marginBottom: 20, fontWeight: 'bold', color: 'purple' }}>
          Chọn một màu bên dưới
        </Text>

        <View style={{ gap: 20 }}>
          <TouchableOpacity
            style={{ width: 100, height: 40, backgroundColor: '#ADD8E6' }}
            onPress={() =>
              navigation.navigate('Home', { selectedColor: 'red' })
            }
          />
          <TouchableOpacity
            style={{ width: 100, height: 40, backgroundColor: 'red' }}
            onPress={() =>
              navigation.navigate('Home', { selectedColor: 'red' })
            }
          />
          <TouchableOpacity
            style={{ width: 100, height: 40, backgroundColor: 'black' }}
            onPress={() =>
              navigation.navigate('Home', { selectedColor: 'red' })
            }
          />
          <TouchableOpacity
            style={{ width: 100, height: 40, backgroundColor: 'purple' }}
            onPress={() =>
              navigation.navigate('Home', { selectedColor: 'red' })
            }
          />
        </View>

        <TouchableOpacity
          style={{
            marginTop: 30,
            width: '80%',
            padding: 15,
            backgroundColor: 'blue',
            borderRadius: 8,
          }}>
          <Text
            style={{ color: 'white', textAlign: 'center', fontWeight: 'bold' }}>
            XONG
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
