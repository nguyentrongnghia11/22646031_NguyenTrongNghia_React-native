import { Text, View, Image, TouchableOpacity } from 'react-native';
import Header from './Header';

export default function HomeScreen({ navigation, route }) {
  const images = {
    blue: require('../assets/vs_blue.png'),
    red: require('../assets/vs_red.png'),
  };

  const { selectedColor } = route.params || 'red';
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={{ alignItems: 'center', marginTop: 10 }}>
        <Image
         source={selectedColor ? images[selectedColor] : images.blue}
          style={{ width: 200, height: 250, resizeMode: 'contain' }}
        />
      </View>

      <Text
        style={{
          marginTop: 10,
          textAlign: 'center',
          fontSize: 16,
        }}>
        Điện Thoại Vsmart Joy 3 - Hàng chính hãng
      </Text>

      {/* Rating */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: 10,
        }}>
        <View style={{ flexDirection: 'row' }}>
          <Image source={require('../assets/star.png')} />
          <Image source={require('../assets/star.png')} />
          <Image source={require('../assets/star.png')} />
          <Image source={require('../assets/star.png')} />
          <Image source={require('../assets/star.png')} />
        </View>
        <Text style={{ marginLeft: 10 }}>(Xem 828 đánh giá)</Text>
      </View>

      {/* Giá */}
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          marginTop: 10,
        }}>
        <Text style={{ textDecorationLine: 'line-through', marginRight: 15 }}>
          1.790.000 đ
        </Text>
        <Text style={{ fontWeight: 'bold', color: 'red' }}>1.790.000 đ</Text>
      </View>

      {/* Ở đâu rẻ hơn */}
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'center',
          alignItems: 'center',
          marginTop: 10,
        }}>
        <Text style={{ marginRight: 5 }}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>
        <Image source={require('../assets/chamhoi.png')} />
      </View>

      {/* Nút chọn màu */}
      <TouchableOpacity
        onPress={() => navigation.navigate('Detail')}
        style={{
          borderWidth: 1,
          borderColor: 'black',
          marginHorizontal: 50,
          marginTop: 15,
          paddingVertical: 10,
        }}>
        <Text style={{ textAlign: 'center' }}>4 MÀU - CHỌN MÀU ></Text>
      </TouchableOpacity>

      {/* Nút chọn mua */}
      <TouchableOpacity
        style={{
          backgroundColor: 'red',
          marginHorizontal: 50,
          marginTop: 10,
          paddingVertical: 12,
        }}>
        <Text
          style={{ textAlign: 'center', color: 'white', fontWeight: 'bold' }}>
          CHỌN MUA
        </Text>
      </TouchableOpacity>
    </View>
  );
}
